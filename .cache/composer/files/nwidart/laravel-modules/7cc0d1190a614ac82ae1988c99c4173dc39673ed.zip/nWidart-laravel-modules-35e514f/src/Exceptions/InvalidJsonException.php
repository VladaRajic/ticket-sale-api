<?php

namespace Nwidart\Modules\Exceptions;

class InvalidJsonException extends \Exception
{
}
